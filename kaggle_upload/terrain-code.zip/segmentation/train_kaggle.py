"""
Kaggle fine-tuning entrypoint for the multi-sensor SwinUNet.

Run on Kaggle (GPU T4 x2, Internet ON):
    !python3 /kaggle/input/terrain-bah2026-code/segmentation/train_kaggle.py

Requires two inputs added to the notebook:
    - terrain-bah2026-code   (repo: config.py + segmentation/)
    - terrain-bah2026-tiles  (archived data/processed tiles)
"""

import os
import subprocess
import sys

for pkg in ["segmentation-models-pytorch", "timm", "albumentations==1.3.1",
            "rasterio", "pyogrio", "scikit-image", "torchmetrics"]:
    subprocess.run([sys.executable, "-m", "pip", "install", pkg, "-q"])

sys.path.insert(0, "/kaggle/input/terrain-bah2026-code")

import torch

import config
from segmentation.train import train_model

config.DATA_DIR = "/kaggle/input/terrain-bah2026-tiles"
config.NORM_STATS_PATH = "/kaggle/input/terrain-bah2026-tiles/data/processed/_norm_stats.json"
config.MODEL_SAVE_PATH = "/kaggle/working/terrain_best.pth"
config.OUTPUT_DIR = "/kaggle/working/"
config.EPOCHS = 40
config.BATCH_SIZE = 8

torch.backends.cudnn.benchmark = True

if __name__ == "__main__":
    print("devices:", torch.cuda.device_count(), "| cuda:", torch.cuda.is_available())
    model, history = train_model(device=torch.device("cuda"))

    best = max(h["val_iou"] for h in history)
    size_mb = os.path.getsize(config.MODEL_SAVE_PATH) / 1e6
    print(f"FINAL best val IoU = {best:.4f} | checkpoint size = {size_mb:.1f} MB")
    print("DOWNLOAD terrain_best.pth FROM KAGGLE OUTPUT TAB NOW")
